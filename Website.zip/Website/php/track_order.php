<?php
header("Content-Type: application/json");

require_once("database_setup.php");
require_once("../backend/OrderTracker.php");

// Load database config and initialize
$configs = require_once 'settings.php';
$db = new Database($configs);
$conn = $db->getConnection();
$orderTracker = new OrderTracker($conn);

// Get input parameters
$orderId = isset($_GET['order_id']) ? trim($_GET['order_id']) : '';
$name    = isset($_GET['name']) ? trim($_GET['name']) : '';
$email   = isset($_GET['email']) ? trim($_GET['email']) : '';
$phone   = isset($_GET['phone']) ? trim($_GET['phone']) : '';

// 🔧 Optional: Enable/Disable debug logs
$debug = false;
if ($debug) {
    file_put_contents("debug_track.log", json_encode([
        'order_id' => $orderId,
        'name'     => $name,
        'email'    => $email,
        'phone'    => $phone,
        'raw_GET'  => $_GET
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
}

try {
    //  Option 1: Search by Order ID
    if (!empty($orderId)) {
        $result = $orderTracker->getByOrderId($orderId);

        if (!$result) {
            echo json_encode(['error' => 'No matching shipment found.']);
            exit;
        }

        echo json_encode([
            'order_id'        => $result['order_id'],
            'tracking_number' => $result['tracking_number'],
            'status'          => $result['status']
        ]);
        exit;
    }

    //  Option 2: Search by Name + (Email or Phone)
    if (!empty($name) && (!empty($email) || !empty($phone))) {
        $results = $orderTracker->getByNameAndContact($name, $email, $phone);

        if (empty($results)) {
            echo json_encode(['error' => 'No matching shipments found.']);
            exit;
        }

        echo json_encode([
            'multiple' => true,
            'orders' => array_map(function ($r) {
                return [
                    'order_id'        => $r['order_id'],
                    'tracking_number' => $r['tracking_number'],
                    'status'          => $r['status']
                ];
            }, $results)
        ]);
        exit;
    }

    // Invalid request: no proper input
    echo json_encode(['error' => 'Please provide either Order ID or Name with Email/Phone.']);
} catch (Exception $e) {
    echo json_encode(['error' => 'Server error: ' . $e->getMessage()]);
}
