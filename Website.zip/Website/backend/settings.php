<?php 
return [
    'host' => 'localhost',
    'user' => 'root',
    'pass' => '',
    'database' => 'electronics_store_db'
];
