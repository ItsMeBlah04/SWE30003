const BaseModel = require('./BaseModel');

class Shipment extends BaseModel {
  constructor(db) {
    super(db);
    this.table = 'shipment';
  }

  // Get shipment by order ID
  async getByOrderId(orderId) {
    const sql = `SELECT * FROM ${this.table} WHERE order_id = ?`;
    return this.query(sql, [orderId]);
  }

  // Create new shipment entry
  async create(orderId, trackingNumber, status = 'Processing') {
    const sql = `INSERT INTO ${this.table} (order_id, tracking_number, status) VALUES (?, ?, ?)`;
    return this.query(sql, [orderId, trackingNumber, status]);
  }

  // Update shipment status
  async updateStatus(orderId, newStatus) {
    const sql = `UPDATE ${this.table} SET status = ? WHERE order_id = ?`;
    return this.query(sql, [newStatus, orderId]);
  }
}

module.exports = Shipment;
