const BaseModel = require('./BaseModel');

class Notifier extends BaseModel {
  constructor(db) {
    super(db);
    this.table = 'notification';
  }

  // Send a new notification (e.g., email or SMS)
  async sendNotification(customerId, type, content) {
    const sql = `
      INSERT INTO ${this.table} (customer_id, type, content, timestamp)
      VALUES (?, ?, ?, NOW())
    `;
    return this.query(sql, [customerId, type, content]);
  }

  // Get all notifications for a specific customer
  async getNotificationsForCustomer(customerId) {
    const sql = `
      SELECT * FROM ${this.table}
      WHERE customer_id = ?
      ORDER BY timestamp DESC
    `;
    return this.query(sql, [customerId]);
  }
}

module.exports = Notifier;
